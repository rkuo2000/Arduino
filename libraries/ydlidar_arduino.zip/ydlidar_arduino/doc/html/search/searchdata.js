var indexSectionsWithContent =
{
  0: "cdlnqsy",
  1: "cdlnqsy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes"
};

