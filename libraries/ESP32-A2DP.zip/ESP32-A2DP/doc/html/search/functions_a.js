var searchData=
[
  ['sample_5frate_87',['sample_rate',['../class_bluetooth_a2_d_p_sink.html#a09a8b269e2a936c5517bd9f88f666a1c',1,'BluetoothA2DPSink']]],
  ['set_5favrc_5fmetadata_5fcallback_88',['set_avrc_metadata_callback',['../class_bluetooth_a2_d_p_sink.html#aac9074521c80d7574a855f30b8301d13',1,'BluetoothA2DPSink']]],
  ['set_5fbits_5fper_5fsample_89',['set_bits_per_sample',['../class_bluetooth_a2_d_p_sink.html#a9ebe4927600f29318133b5f11e0ab7f8',1,'BluetoothA2DPSink']]],
  ['set_5fi2s_5fconfig_90',['set_i2s_config',['../class_bluetooth_a2_d_p_sink.html#a39329de792f43f90a16f9ab2ee62814f',1,'BluetoothA2DPSink']]],
  ['set_5fi2s_5fport_91',['set_i2s_port',['../class_bluetooth_a2_d_p_sink.html#ab4e52dff7ef08f17cfce4e011cdd6542',1,'BluetoothA2DPSink']]],
  ['set_5fmono_5fdownmix_92',['set_mono_downmix',['../class_bluetooth_a2_d_p_sink.html#a624040cce89a4a2f66495f57db6c1457',1,'BluetoothA2DPSink']]],
  ['set_5fon_5fdata_5freceived_93',['set_on_data_received',['../class_bluetooth_a2_d_p_sink.html#af65219e635fadbbc90f4663b33abd3e0',1,'BluetoothA2DPSink']]],
  ['set_5fpin_5fconfig_94',['set_pin_config',['../class_bluetooth_a2_d_p_sink.html#af7ce8131af4f085e94eb81e3fcbfc4af',1,'BluetoothA2DPSink']]],
  ['set_5fstream_5freader_95',['set_stream_reader',['../class_bluetooth_a2_d_p_sink.html#a4f94426ff4899c437d31623e013cf7a5',1,'BluetoothA2DPSink']]],
  ['setnvsinit_96',['setNVSInit',['../class_bluetooth_a2_d_p_source.html#aca730d4953402b8ba1a9f8c8affbf8b7',1,'BluetoothA2DPSource']]],
  ['setpincode_97',['setPinCode',['../class_bluetooth_a2_d_p_source.html#afb97a3f9a71350523c44774deebecc8c',1,'BluetoothA2DPSource']]],
  ['setresetble_98',['setResetBLE',['../class_bluetooth_a2_d_p_source.html#a0d930cfb6d6c19e8c02fe95a2c1c7dd7',1,'BluetoothA2DPSource']]],
  ['start_99',['start',['../class_bluetooth_a2_d_p_sink.html#a8d6eae21dcf699b671b897f53498eaa9',1,'BluetoothA2DPSink::start()'],['../class_bluetooth_a2_d_p_source.html#aa95c962faf036331a4cc6cff3e296bd8',1,'BluetoothA2DPSource::start(char *name, music_data_channels_cb_t callback=NULL, bool is_ssp_enabled=false)']]],
  ['startraw_100',['startRaw',['../class_bluetooth_a2_d_p_source.html#a1c6030ee1e7e41282156fd0013a956f5',1,'BluetoothA2DPSource']]],
  ['stop_101',['stop',['../class_bluetooth_a2_d_p_sink.html#a37dcbcd418b84310ccedf3330e44834f',1,'BluetoothA2DPSink']]]
];
