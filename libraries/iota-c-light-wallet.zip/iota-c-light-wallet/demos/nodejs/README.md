# NodeJS Demo

Currently, there is no separate demo for trying IOTA using NodeJS and Ledger Nano S. Please go to the [special IOTA-branch on our ledgerjs-fork](https://github.com/IOTA-Ledger/ledgerjs/tree/iota-js) to run the tests there.
