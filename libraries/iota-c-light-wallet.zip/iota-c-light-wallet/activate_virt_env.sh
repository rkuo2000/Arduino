#!/bin/bash
/bin/bash --rcfile .pyenv/bin/activate
